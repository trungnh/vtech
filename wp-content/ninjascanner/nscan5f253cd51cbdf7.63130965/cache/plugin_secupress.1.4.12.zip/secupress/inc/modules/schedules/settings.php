<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'schedules-backups' );
$this->load_plugin_settings( 'schedules-scan' );
$this->load_plugin_settings( 'schedules-file-monitoring' );
