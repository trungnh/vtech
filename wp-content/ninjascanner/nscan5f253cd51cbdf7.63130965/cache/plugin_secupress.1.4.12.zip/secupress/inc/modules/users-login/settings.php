<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'move-login' );
$this->load_plugin_settings( 'login-protection' );
$this->load_plugin_settings( 'double-auth' );
$this->load_plugin_settings( 'password-policy' );
$this->load_plugin_settings( 'blacklist-logins' );
