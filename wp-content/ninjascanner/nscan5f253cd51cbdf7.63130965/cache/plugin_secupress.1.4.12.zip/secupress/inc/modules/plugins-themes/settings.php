<?php
defined( 'ABSPATH' ) or die( 'Cheatin&#8217; uh?' );

$this->load_plugin_settings( 'uploads' );
$this->load_plugin_settings( 'plugins' );
$this->load_plugin_settings( 'themes' );
