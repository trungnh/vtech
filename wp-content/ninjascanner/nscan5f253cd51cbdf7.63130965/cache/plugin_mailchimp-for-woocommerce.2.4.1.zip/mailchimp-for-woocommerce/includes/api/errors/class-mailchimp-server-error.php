<?php

/**
 * Class MailChimp_WooCommerce_ServerError
 */
class MailChimp_WooCommerce_ServerError extends MailChimp_WooCommerce_Error
{

}
