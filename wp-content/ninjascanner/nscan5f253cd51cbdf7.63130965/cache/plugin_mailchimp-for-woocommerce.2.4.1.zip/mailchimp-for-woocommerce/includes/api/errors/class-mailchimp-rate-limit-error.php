<?php

/**
 * Class MailChimp_WooCommerce_RateLimitError
 */
class MailChimp_WooCommerce_RateLimitError extends MailChimp_WooCommerce_Error
{

}
